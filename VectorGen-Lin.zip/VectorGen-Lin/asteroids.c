// Dutchtronix AVR Oscilloscope Clock
//
//  Copyright � 2010 Johannes P.M. de Rie
//
//  All Rights Reserved
//
//  This file is part of the Dutchtronix Oscilloscope Clock Distribution.
//  Use, modification, and re-distribution is permitted subject to the
//  terms in the file named "LICENSE.TXT", which contains the full text
//  of the legal notices and should always accompany this Distribution.
//
//  This software is provided "AS IS" with NO WARRANTY OF ANY KIND.
//
//  This notice (including the copyright and warranty disclaimer)
//  must be included in all copies or derivations of this software.
//
//  Changes to be able to compile under Linux - search //PC
//  2021-04-14 Peter Sieg

typedef unsigned char uint8_t;
#define MAXVECTENTRIES 128
#define MAXLINESIZE 20
#define MAXLINES 14
#define LASTLINEPOS 13
#define MAXWIDTH 255
#define MAXHEIGHT 255

#define TERMESCAPE 0xff
enum VectCommands {
	VectNone,
	VectEntry = 0xf0,		//5 arg bytes
	VectRange = 0xf1,		//2 arg bytes
	TermSetCursor = 0xf2,	//2 arg bytes
	TermSetCursorCtl = 0xf3,//1 arg byte
	TermSetClkLine = 0xf4,	//1 arg byte
	TermSetBurnIn = 0xf5,	//1 arg byte
	TermSetCtrl = 0xf6		//1 arg byte
} ;
void VGSetCursorCtl(BOOL b)
{
	UARTSendByte(TERMESCAPE, TRUE);
	UARTSendByte(TermSetCursorCtl, TRUE);
	UARTSendByte(b, TRUE);
}

void VGSetCursorPos(uint8_t XOffset, uint8_t YOffset)
{
	UARTSendByte(TERMESCAPE, TRUE);
	UARTSendByte(TermSetCursor, TRUE);
	UARTSendByte(XOffset, TRUE);
	UARTSendByte(YOffset, TRUE);
}

void VGSetClkLine(BOOL b)
{
	UARTSendByte(TERMESCAPE, TRUE);
	UARTSendByte(TermSetClkLine, TRUE);
	UARTSendByte(b, TRUE);
}

void VGSetBurnIn(BOOL b)
{
	UARTSendByte(TERMESCAPE, TRUE);
	UARTSendByte(TermSetBurnIn, TRUE);
	UARTSendByte(b, TRUE);
}

void VGClearScreen(void)
{
	UARTSendByte(TERMESCAPE, TRUE);
	UARTSendByte(TermSetCtrl, TRUE);
	UARTSendByte(0, TRUE);
}

void VGSendSync(void)
{
	UARTSendByte(TERMESCAPE, TRUE);
	UARTSendByte(TERMESCAPE, TRUE);
}

void VGSetRange(uint8_t idx1, uint8_t len)
{
	if (len > MAXVECTENTRIES) len = 0;
	UARTSendByte(TERMESCAPE, TRUE);
	UARTSendByte(VectRange, TRUE);
	UARTSendByte(idx1 & 0xff, TRUE);
	UARTSendByte(len & 0xff, TRUE);
}

void VGSetVector(uint8_t idx1, uint8_t v[3])
{
	if (idx1 >= MAXVECTENTRIES) idx1 = 0;
	UARTSendByte(TERMESCAPE, TRUE);
	UARTSendByte(VectEntry, TRUE);
	UARTSendByte(idx1, TRUE);
	UARTSendByte(v[0], TRUE);
	UARTSendByte(v[1], TRUE);
	UARTSendByte(v[2], TRUE);
	UARTSendByte(v[3], TRUE);
}

void VGSetString(uint8_t XOffset, uint8_t YOffset, char *pStr)
{
	char ch;
	VGSetCursorPos(XOffset, YOffset);
	//now send string as regular char terminal input
	while ((ch = *pStr++) != 0) {
		UARTSendByte(ch, TRUE);
	}
}

void VGSetOneVector(uint8_t idx1, uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1)
{
	if (idx1 >= MAXVECTENTRIES) idx1 = 0;
	UARTSendByte(TERMESCAPE, TRUE);
	UARTSendByte(VectEntry, TRUE);
	UARTSendByte(idx1, TRUE);
	UARTSendByte(x0, TRUE);
	UARTSendByte(y0, TRUE);
	UARTSendByte(x1, TRUE);
	UARTSendByte(y1, TRUE);
}

void SetFrame(void)
{
	int x,y;
	VGSetCursorCtl(FALSE);
	VGSetClkLine(FALSE);
	VGSetBurnIn(FALSE);			//no burnin protection active
	VGSetCursorPos(0, 0);
	// no need to clear last line
	for (y = 0; y < (MAXLINES - 1); ++y) {		//TODO
		for (x = 0; x < MAXLINESIZE; ++x) {	//TODO
			UARTSendByte(' ', TRUE);
		}
	}
	VGSetOneVector(0, 0, 0, 0, MAXHEIGHT);
	VGSetOneVector(1, 0, MAXHEIGHT, MAXWIDTH, MAXHEIGHT);
	VGSetOneVector(2, MAXWIDTH, MAXHEIGHT, MAXWIDTH, 0);
	VGSetOneVector(3, MAXWIDTH, 0, 0, 0);
}
/******************************************
 * MegaAsteroids
 *      An Asteroids game clone for the TouchShield, Arduino, and InputShield.
 *
 *      By Christopher Ladden @ liquidware.com
 *
 *      For use with the TouchShield from liquidware
 *      TouchShield Slide : http://www.liquidware.com/shop/show/TSL/TouchShield+Slide
 *      InputShield : http://www.liquidware.com/shop/show/INPT/InputShield
 *      Arduino Mega : http://www.liquidware.com/shop/show/AMEGA/Arduino+Mega
 *
 ******************************************/
/***************************************************
 * Structures
 ***************************************************/
typedef struct {
    int width;
    int height;
} sizer_t;

typedef struct {
    int x;
    int y;
} vect2_t;

typedef struct {
    uint8_t x;
    uint8_t y;
} point_t;

typedef struct {
    point_t p0;
    point_t p1;
} vect_t;

typedef struct {
    int left;
    int top;
    int right;
    int bottom;
} rect_t;

typedef struct {
    rect_t bounds;
    vect2_t PL;
    vect2_t maxSpeed;
    vect2_t V;
    vect2_t L;
    sizer_t size;
    sizer_t pSize;
    BOOL    visible;
    int     rotation;
} player_t;

typedef struct {
    float decay;
    vect2_t SPEED;
    int maxSpeed;
    int minSpeed;
    int shotcount;
    int rotation;
    vect2_t VT;
    vect2_t PREV_P1;
    vect2_t PREV_P2;
    vect2_t PREV_P3;
} ship_data_t;

typedef struct {
    ship_data_t data;
    player_t    player;
} ship_t;

typedef struct {
    vect2_t L;
    vect2_t PL;
    vect2_t V;
    int rotation;
    BOOL  visible;
} bullet_t;

/***************************************************
 * Global Variables and Constants
 ***************************************************/

// Initialize a new ship structure
ship_t ship = {
/* data */
    {
        /* decay */     0.97,
        /* SPEED */     {0, 0},
        /* maxSpeed */  17,
        /* minSpeed */ -17,
        /* shotCount */ 1,
        /* rotation */  0,
        /* VT */        {0, 0},
        /* PREV_P1 */   {0, 0},
        /* PREV_P2 */   {0, 0},
        /* PREV_P3 */   {0, 0},
    },
/* player */
    {
        /* bounds */      {0, 0, 0, 0},
        /* PL */          {100, 100},
        /* maxSpeed */    {10, 10},
        /* V */           {2, 2},
        /* L */           {100, 100},
        /* size */        {20, 20},
        /* pSize */       {20, 20},
        /* visible */     TRUE,
        /* rotation */    0,
    },
};

// A bunch of asteroids, only one initialized to a known value.
player_t asteroidList[kMaxAsteroids] = {
    {
        /* bounds */      {0, 0, 0, 0},
        /* PL */          {200, 200},
        /* maxSpeed */    {2, 2},
        /* V */           {1, 1},
        /* L */           {200, 200},
        /* size */        {20, 20},
        /* pSize */       {20, 20},
        /* visible */     TRUE,
        /* rotation */    145,
    }
};

bullet_t bullets[kMaxBullets];

#define SHIPVECTSIZE 8
#define FRAMEVECTSIZE 4
#define ASTEROIDVECTSIZE 8
#define BULLETVECTSIZE 1
#define MAXVECTTBL (kMaxAsteroids*ASTEROIDVECTSIZE + kMaxBullets*BULLETVECTSIZE)

vect_t vectbl[MAXVECTTBL+1];			// maximum size, 1 extra
int	 vtblidx, curidx, maxidx;

/* Controller Buttons */
BOOL uBut = FALSE;
BOOL dBut = FALSE;
BOOL lBut = FALSE;
BOOL rBut = FALSE;
BOOL fDemoMode = FALSE;
BOOL fExit = FALSE;

unsigned long kTime = 0;
unsigned long pTime = 0;
unsigned long fTime = 0;
int dt = kFrameDuration;
char out[50];
long aPTime = 0;
unsigned long score = 0;
uint lives = 3;
//
// Vector Table layout
//
// 0..3:  game boundaries
//
// 4,5,6,: ship (3 vectors) fixed.
//
// +40/80   asteroid (10/20 * 4 vectors max)
//
// +25  bullets (25 * 1 vectors max)
//
// not all asteroids & bullets visible at all times so
// compute local vector table for asteroids & bullets with
// visible entries, then send the local vector table
// and set the actual range.
//  
uint8_t rangex(int x)
{
	if (x > MAXWIDTH) return MAXWIDTH;
	else if (x < 0) return 0;
	else return (uint8_t)x;
}

uint8_t rangey(int y)
{
	uint8_t ret;
	if (y > MAXHEIGHT) ret = MAXHEIGHT;
	else if (y < 0) ret = 0;
	else ret = (uint8_t)y;
	return ret;
}

/***************************************************
 * Local Function Routines
 ***************************************************/
void stroke(int color)
{
}

void fill(int flag)
{
}

void noFill(void)
{
}

void background(int flag)
{
}

int mrandom(int max)
{
	int v = rand() % (max + 1);
	return v;
}

int mrandom2(int vmin, int vmax)
{
	int v = (int)rand() % ((vmax + 1 - vmin)) + vmin;
	return v;
}

// Setup the game
//*******************************************************
void setup() {
	int x;	//, y;

	kTime = GetTickCount();
	fTime = GetTickCount();
	curidx = maxidx = 0;
    background(0);
    fill(0);
    stroke(255);

    /* Setup Asteroids */
    for (x = 0; x < kMaxAsteroids; x++) {
        asteroidList[x].visible = FALSE;
        asteroidList[x].size.width = 20;
        asteroidList[x].size.height = 20;
    }
	SetFrame();
	VGSetRange(0, FRAMEVECTSIZE);
}
// Draw the asteroids
//*******************************************************
void drawAsteroid(uint8_t * asteroidList) {
	int x;
    player_t * a = (player_t*)asteroidList;

    for (x = 0; x < kMaxAsteroids; x++) {
        if (a[x].visible) {
            vect2_t *L = &a[x].L;
            sizer_t *size =  &a[x].size;

            noFill();
            stroke(mrandom(255));
			vectbl[vtblidx].p0.x = rangex(L->x);
			vectbl[vtblidx].p0.y = rangey(L->y);
			vectbl[vtblidx].p1.x = rangex(L->x + size->width/2);
			vectbl[vtblidx].p1.y = rangey(L->y + size->height/3);

			vectbl[vtblidx+1].p0.x = rangex(L->x + size->width/2);
			vectbl[vtblidx+1].p0.y = rangey(L->y + size->height/3);
			vectbl[vtblidx+1].p1.x = rangex(L->x + size->width);
			vectbl[vtblidx+1].p1.y = rangey(L->y);

			vectbl[vtblidx+2].p0.x = rangex(L->x + size->width);
			vectbl[vtblidx+2].p0.y = rangey(L->y);
			vectbl[vtblidx+2].p1.x = rangex(L->x + size->width/3 * 2);
			vectbl[vtblidx+2].p1.y = rangey(L->y + size->height/2);

			vectbl[vtblidx+3].p0.x = rangex(L->x + size->width/3 * 2);
			vectbl[vtblidx+3].p0.y = rangey(L->y + size->height/2);
			vectbl[vtblidx+3].p1.x = rangex(L->x + size->width);
			vectbl[vtblidx+3].p1.y = rangey(L->y + size->height);

			vectbl[vtblidx+4].p0.x = rangex(L->x + size->width);
			vectbl[vtblidx+4].p0.y = rangey(L->y + size->height);
			vectbl[vtblidx+4].p1.x = rangex(L->x + size->width/2);
			vectbl[vtblidx+4].p1.y = rangey(L->y + size->height/3 * 2);

			vectbl[vtblidx+5].p0.x = rangex(L->x + size->width/2);
			vectbl[vtblidx+5].p0.y = rangey(L->y + size->height/3 * 2);
			vectbl[vtblidx+5].p1.x = rangex(L->x);
			vectbl[vtblidx+5].p1.y = rangey(L->y + size->height);

			vectbl[vtblidx+6].p0.x = rangex(L->x);
			vectbl[vtblidx+6].p0.y = rangey(L->y + size->height);
			vectbl[vtblidx+6].p1.x = rangex(L->x + size->width/3);
			vectbl[vtblidx+6].p1.y = rangey(L->y + size->height/2);

			vectbl[vtblidx+7].p0.x = rangex(L->x + size->width/3);
			vectbl[vtblidx+7].p0.y = rangey(L->y + size->height/2);
			vectbl[vtblidx+7].p1.x = rangex(L->x);
			vectbl[vtblidx+7].p1.y = rangey(L->y);
			vtblidx += ASTEROIDVECTSIZE;
        }
    }
	if (vtblidx > MAXVECTTBL) {
#ifdef _WIN32
		printf("Error: vecttbl overflow\n");
#else
		xprintf("Error: vecttbl overflow\n");
#endif
		exit(1);
	}
}


// Draw the player's space ship
//*******************************************************
void drawShip(uint8_t * ship, BOOL fGenC) {
    ship_t * s = (ship_t*)ship;
    ship_data_t * sData = &s->data;
    player_t * p = (player_t*)&s->player;
    vect2_t *L = &p->L;
    vect2_t p1;
    vect2_t p2;
    vect2_t p3;
    vect2_t p4;
    vect2_t p5;
    vect2_t p6;
    vect2_t p7;

    /* Paint the new ship */

    //Generate the three points that
    //outline the ship using some trig based
    //on our current location and rotation
    p1.x = (int)(sin((sData->rotation + 90) * 0.017453) * 10.0);  //PI / 180 = 0.017453
    p1.y = (int)(-cos((sData->rotation + 90) * 0.017453) * 10.0);

    p2.x = sin((sData->rotation + 230.0) * 0.017453) * 10.0;  //PI / 180 = 0.017453
    p2.y = -cos((sData->rotation + 230.0) * 0.017453) * 10.0;

    p3.x = sin((sData->rotation + 310.0) * 0.017453) * 10.0;  //PI / 180 = 0.017453
    p3.y = -cos((sData->rotation + 310.0) * 0.017453) * 10.0;

    p4.x = sin((sData->rotation + 259.0) * 0.017453) * 35.0;  //PI / 180 = 0.017453
    p4.y = -cos((sData->rotation + 259.0) * 0.017453) * 35.0;

    p5.x = sin((sData->rotation + 281.0) * 0.017453) * 35.0;  //PI / 180 = 0.017453
    p5.y = -cos((sData->rotation + 281.0) * 0.017453) * 35.0;

    p6.x = sin((sData->rotation + 256.0) * 0.017453) * 44.0;  //PI / 180 = 0.017453
    p6.y = -cos((sData->rotation + 256.0) * 0.017453) * 44.0;

    p7.x = sin((sData->rotation + 284.0) * 0.017453) * 44.0;  //PI / 180 = 0.017453
    p7.y = -cos((sData->rotation + 284.0) * 0.017453) * 44.0;

    p1.x = rangex(p1.x + L->x);
    p1.y = rangey(p1.y + L->y);

    p2.x = rangex(p2.x + L->x);
    p2.y = rangey(p2.y + L->y);

    p3.x = rangex(p3.x + L->x);
    p3.y = rangey(p3.y + L->y);

    p4.x = rangex(p4.x + L->x);
    p4.y = rangey(p4.y + L->y);

    p5.x = rangex(p5.x + L->x);
    p5.y = rangey(p5.y + L->y);

    p6.x = rangex(p6.x + L->x);
    p6.y = rangey(p6.y + L->y);

    p7.x = rangex(p7.x + L->x);
    p7.y = rangey(p7.y + L->y);

    //Connect the three points to form the
    //shape of our ship.

	if (fGenC) {
		printf("\t{0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x},\n", p1.x, p1.y,p2.x, p2.y);
		printf("\t{0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x},\n", p2.x, p2.y,p3.x, p3.y);
		printf("\t{0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x},\n", p3.x, p3.y,p1.x, p1.y);
		printf("\t{0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x},\n", p2.x, p2.y,p4.x, p4.y);
		printf("\t{0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x},\n", p4.x, p4.y,p5.x, p5.y);
		printf("\t{0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x},\n", p5.x, p5.y,p3.x, p3.y);
		printf("\t{0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x},\n", p4.x, p4.y,p6.x, p6.y);
		printf("\t{0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x},\n", p5.x, p5.y,p7.x, p7.y);
	} else {
		byte i = FRAMEVECTSIZE;
		stroke(255);
		//p1 is point of triangle
		VGSetOneVector(i++, p1.x, p1.y,p2.x, p2.y);
		VGSetOneVector(i++, p2.x, p2.y,p3.x, p3.y);
		VGSetOneVector(i++, p3.x, p3.y,p1.x, p1.y);
		VGSetOneVector(i++, p2.x, p2.y, p4.x, p4.y);
		VGSetOneVector(i++, p4.x, p4.y, p5.x, p5.y);
		VGSetOneVector(i++, p5.x, p5.y, p3.x, p3.y);
		VGSetOneVector(i++, p4.x, p4.y, p6.x, p6.y);
		VGSetOneVector(i++, p5.x, p5.y, p7.x, p7.y);
	}
}

// Draw the bullets moving on the screen
//*******************************************************
void drawBullets(uint8_t *bullets) {
	int x;
    bullet_t * b = (bullet_t*)bullets;

    for (x = 0; x < kMaxBullets; x++) {
        if (b[x].visible) {
            vect2_t * L = &b[x].L;
            /* Paint the new */
            stroke(mrandom(255));
//            point(L->x, L->y);
			vectbl[vtblidx].p0.x =rangex(L->x);
			vectbl[vtblidx].p0.y =rangey(L->y);
			vectbl[vtblidx].p1.x =rangex(L->x + 1);
			vectbl[vtblidx].p1.y =rangey(L->y + 1);

			if ((vectbl[vtblidx].p0.x == 0) &&
				(vectbl[vtblidx].p0.y == 0) &&
				(vectbl[vtblidx].p1.x == 0) &&
				(vectbl[vtblidx].p1.y == 0)) {
				printf("\ndrawBullets: empty vector\n");
			}
			vtblidx += 1;
        }
    }
	if (vtblidx > MAXVECTTBL) {
#ifdef _WIN32
		printf("Error: vecttbl overflow\n");
#else
		xprintf("Error: vecttbl overflow\n");
#endif
		exit(1);
	}
}

//RePaint the score on the screen
//*******************************************************
void drawScore() {
	static unsigned long ScoreMillis = 0;
	char out[MAXLINESIZE+2];		//room for CR
	char *pDemoText;
	if (fDemoMode) pDemoText = "(demo)"; else pDemoText = "      ";
    if ( (GetTickCount() - ScoreMillis) > 60) {		// 1000 / 16.66
        ScoreMillis = GetTickCount();
		if (score > 999999) score = 0;
#ifdef _WIN32
		//PS sprintf_s(out, MAXLINESIZE+2 ,"Score: %6ld %s", score, pDemoText);
		sprintf(out, "Score: %6ld %s\r", score, pDemoText);	//max 999,999
#else
		sprintf(out, "Score: %6ld %s\r", score, pDemoText);	//max 999,999
#endif
		out[MAXLINESIZE+1] = 0;
		VGSetString(0, LASTLINEPOS, out);		//TODO should be line 13
	}
#ifndef TERMOUTONLY
#ifdef _WIN32
	printf("Score: %ld  Lives: %d  CurIdx: %d  MaxIdx: %d\r", score, lives, curidx, maxidx);
#else
//	GLCD_TextGoTo(0,0);
	xprintf("\rScore: %ld  Lvs: %d  Idx: %d  Max: %d\r", score, lives, curidx, maxidx);
//	GLCD_TextGoTo(0,2);
#endif
#endif
}


// Move the bullets and perform hit detection
//*******************************************************
void updateBullets(uint8_t *bullets, uint8_t *ship, uint8_t * asteroidList) {
	int i, x;
    bullet_t * b = (bullet_t*)bullets;
    ship_t * s = (ship_t*)ship;
    player_t * a = (player_t*)asteroidList;

    /* Check for available bullets to fire */
    if (dBut) {
        for (x = 0; x < kMaxBullets; x++) {
                                                                                                                   
            if (!b[x].visible) {
                // Get the bullet ready to fire by setting
                // the bullet's location and rotation to the
                // ship's current location and rotation
                memcpy(&b[x].L, &s->player.L, sizeof(b[x].L));
                b[x].rotation = s->data.rotation;

                // Fire!!
                b[x].visible = TRUE;
                break;
            }
        }
    }

    /* Move the fired bullets */
    for (x = 0; x < kMaxBullets; x++) {
        if (b[x].visible) {
            vect2_t * L = &b[x].L;
            vect2_t * V = &b[x].V;
                 
            V->x = (int)(7 * cos(b[x].rotation * 0.017453));
            V->y = (int)(7 * sin(b[x].rotation * 0.017453));

            L->x += V->x;
            L->y += V->y;

            // Check if the bullet is off screen
            // reset it's visibility if it's off screen
            if ( (L->x > MAXWIDTH) || (L->y > MAXHEIGHT) ||
                 (L->x < 0) || (L->y < 0)) {
                b[x].visible = FALSE;
            }

            // Check to see if the bullet hit an asteroid
            for (i = 0; i < kMaxAsteroids; i++) {
                rect_t * aBounds =  &a[i].bounds;
                sizer_t * aSize =  &a[i].size;

                // Check the bounds of the asteroid for
                // a missle collision.
                if ((L->x > aBounds->left) && (L->x < aBounds->right) &&
                    (L->y > aBounds->top) && (L->y < aBounds->bottom)) {
                    aSize->width -= 4;
                    aSize->height -= 4;
			        sound (SOUND_ASTRO_SHIP_SHOOT);
                    score += 50;         //You got em, have some points!
                }
            }
        }
    }
}

// Update the space ship's location
//*******************************************************
void updateShip(uint8_t * ship) {
    ship_t * s = (ship_t*)ship;
    ship_data_t * sData = &s->data;
    player_t * p = (player_t*)&s->player;
    vect2_t *L = &p->L;
    vect2_t *V = &p->V;

    sData->VT.x = (int)(sin((sData->rotation + 90.0) * 0.017453) * 4.0);  //PI / 180 = 0.017453
    sData->VT.y = (int)(-cos((sData->rotation + 90.0) * 0.017453) * 4.0);

    L->x += V->x;
    L->y += V->y;

    //Check the controller for ship rotation
    if (lBut) {
        sData->rotation -= 15;
    }
    if (rBut) {
        sData->rotation += 15;
    }

    //Check the controller for Ship acceleration
    if (uBut) {
        if ((V->x > sData->minSpeed) && (V->x < sData->maxSpeed)) {
            V->x += sData->VT.x;
        }
        if ((V->y > sData->minSpeed) && (V->y < sData->maxSpeed)) {
            V->y += sData->VT.y;
        }
    } else {
        V->x *= (int)sData->decay;
        V->y *= (int)sData->decay;
    }

    // Check ship's location and set the off-screen behavoir to
    // loop back around to the other side
    if (L->x < 0) {
        L->x = MAXWIDTH;
    }
    if (L->x > MAXWIDTH) {
        L->x = 0;
    }
    if (L->y > MAXHEIGHT) {
        L->y = 0;
    }
    if (L->y < 0) {
        L->y = MAXHEIGHT;
    }
}

// Update the asteroid's location
//*******************************************************
void updateAsteroid(uint8_t * asteroidList, uint8_t * ship) {
	int x;
    player_t * a = (player_t*)asteroidList;


    /* Loop through the asteroids */
    for (x = 0; x < kMaxAsteroids; x++) {
        vect2_t * L = &a[x].L;
        vect2_t * V = &a[x].V;
        rect_t * aBounds =  &a[x].bounds;
        sizer_t * aSize =  &a[x].size;

        // If the asteroid is visible, that means we
        // can update it's location.
        if (a[x].visible) {
            V->x = (int)(3 * cos(a[x].rotation * 0.017453));
            V->y = (int)(3 * sin(a[x].rotation * 0.017453));

            L->x += V->x;
            L->y += V->y;

            //Update the bounds because our size could have changed
            aBounds->left = L->x;
            aBounds->top = L->y;
            aBounds->right = L->x + aSize->width;
            aBounds->bottom = L->y + aSize->height;

            //Let the asteroids wrap around the screen
            if ((L->x > MAXWIDTH)) {
                L->x = 0;
            }
            if ((L->x < 0)) {
                L->x = MAXWIDTH;
            }

            //Check to see if the asteroid is sufficiently
            //off-screen or blown-up to disable it's visibility
            if (L->y > (MAXHEIGHT - 3) /* 280 */) {
                a[x].visible = FALSE;
            }
            if (L->x > (MAXWIDTH - 3)) {
                a[x].visible = FALSE;
            }
            if (aSize->width < 6) {
                a[x].visible = FALSE;
                score += 100;           //Good job, more points!
            }
        } else {

            // Allow an asteroid to show up using
            // a mrandom time interval
            if ( (GetTickCount() - aPTime) > (uint)mrandom2(kMinNewAsteroidInterval, kMaxNewAsteroidInterval)) {
                a[x].visible = TRUE;
                L->x = mrandom(MAXWIDTH - kDefaultAsteroidSize);
                L->y = -10;
                a[x].rotation = mrandom2(50,130);
                aSize->width = kDefaultAsteroidSize;
                aSize->height = kDefaultAsteroidSize;
                aPTime = GetTickCount();
            }
        }
    }
}

//*******************************************************
void pollController()
{
	static int FireCnt = 10;
	dBut = lBut = rBut = uBut = FALSE;
#ifdef _WIN32
	if (_kbhit()) {
		unsigned char ch = _getch();
		fDemoMode = FALSE;
//PS
		if (ch == ' ') {
			dBut = TRUE;
		}
		if (ch == 'a') {
			rBut = TRUE;
		}
		if (ch == 's') {
			lBut = TRUE;
		}
		if (ch == 'w') {
			uBut = TRUE;
		}
		if (ch == 'x') {
			fExit = TRUE;
		}
/*//PS		if (ch == ' ') {
			dBut = TRUE;
		} else if (ch == 0xe0) {		//arrow
			ch = _getch();
			if (ch == 0x4d) {		//right arrow
				rBut = TRUE;
			} else if (ch == 0x4b) {	//left arrow
				lBut = TRUE;
			} else if (ch == 0x48) {	//up arrow
				uBut = TRUE;
			} else
				printf("key hex value: %2x ", ch);
		} else if ((ch == 'x') || (ch == 'X')) {
				fExit = TRUE;
		} else {
			printf("key hex value: %2x ", ch);
		}
*/
#else
	if (GPIOR0 & ((_BV(fUPS1)|_BV(fUPS2)|_BV(fUPS3)|_BV(fUPS4)))) {
		fDemoMode = FALSE;
		if (GPIOR0 & (_BV(fUPS1))) {
			GPIOR0 &= ~_BV(fUPS1);
			dBut = TRUE;
		}
		if (GPIOR0 & (_BV(fUPS2))) {
			GPIOR0 &= ~_BV(fUPS2);
			rBut = TRUE;
		}
		if (GPIOR0 & (_BV(fUPS3))) {
			GPIOR0 &= ~_BV(fUPS3);
			lBut = TRUE;
		}
		if (GPIOR0 & (_BV(fUPS4))) {
			GPIOR0 &= ~_BV(fUPS4);
			uBut = TRUE;
		}
#endif
		kTime = GetTickCount();
	} else {
		if (GetTickCount() - kTime > kDemoWaitTime) {
			fDemoMode = TRUE;
			--FireCnt;
			if (FireCnt < 4) {
				dBut = TRUE;
			}
			if (FireCnt == 0) {
				FireCnt = mrandom2(2,20);
				if (mrandom(100) > 55) rBut = TRUE; else lBut = TRUE;
//				if (mrandom(100) > 1) uBut = TRUE;
			}
		}
	}
}


// This is the Main Game Loop which
// is frame rate controlled
//*******************************************************
void gameLoop() {
	byte i;
    updateShip((uint8_t*)&ship);
    updateBullets((uint8_t*)&bullets, (uint8_t*)&ship, (uint8_t*)&asteroidList);
    updateAsteroid((uint8_t*)&asteroidList, (uint8_t*)&ship.player);

	vtblidx = 0;
    drawShip((uint8_t*)&ship, FALSE);
    drawAsteroid((uint8_t*)&asteroidList);
    drawBullets((uint8_t*)&bullets);
	// sendvtbl
	for (i = 0; i < vtblidx; ++i) {
		VGSetOneVector(	FRAMEVECTSIZE + SHIPVECTSIZE + i,
			vectbl[i].p0.x,
			vectbl[i].p0.y,
			vectbl[i].p1.x,
			vectbl[i].p1.y);
	}
	curidx = FRAMEVECTSIZE + SHIPVECTSIZE + vtblidx - 1;
	VGSetRange(0, curidx + 1);
	if (curidx > maxidx) {
		maxidx = curidx;
	}
	VGSendSync();
	drawScore();
#if 0
	if (maxidx >= 100) {
		//
		// emit the complete vectbl in C init form
		//
		printf("\nVect_t VectSamples[] PROGMEM = {\n");
		//frame:
		printf("\t{0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x},\n", 0, 0, 0, MAXHEIGHT);
		printf("\t{0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x},\n", 0, MAXHEIGHT, MAXWIDTH, MAXHEIGHT);
		printf("\t{0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x},\n", MAXWIDTH, MAXHEIGHT, MAXWIDTH, 0);
		printf("\t{0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x},\n", MAXWIDTH, 0, 0, 0);
		//ship
	    drawShip((uint8_t*)&ship, TRUE);
		//rest:
		for (i = 0; i < vtblidx - 1; ++i) {
			printf("\t{0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x},\n",
				vectbl[i].p0.x,	vectbl[i].p0.y,
				vectbl[i].p1.x,	vectbl[i].p1.y);
		}
		printf("\t{0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x}\n",
			vectbl[vtblidx - 1].p0.x,	vectbl[vtblidx - 1].p0.y,
			vectbl[vtblidx - 1].p1.x,	vectbl[vtblidx - 1].p1.y);
		printf("\n};\n");
		exit(1);
	}
#endif
    pollController();
}


// The main loop the program. All this does
// is keep the frame rate constant for the game loop
//*******************************************************
void loop() {
    if ( (GetTickCount() - pTime) > kFrameDuration) {
        pTime = GetTickCount();
        gameLoop();
    }
    if ( (GetTickCount() - fTime) > kFrameRedrawTime) {	// 1000/16.66
		SetFrame();
		fTime = GetTickCount();
	}
}

void Asteroid(void)
{
	char c = 0;
	VGSendSync();
	VGSetRange(0, 0);
	VGSetCursorCtl(FALSE);
	VGSetClkLine(FALSE);
	VGClearScreen();
	VGSetString(5, 6, "Dutchtronix");
#ifndef TERMOUTONLY
#ifdef _WIN32
	Sleep(2);
	VGSetString(2, 6, "<space> to start ");
	do {
	  if (_kbhit()) {
	    c = _getch();
	  }
	}  while (c != ' ');
	
//PS	while (TRUE) {
//	  if (_kbhit() && (_getch() == ' '))
//		break;
//	}
#else
	_delay_ms(2000);
	VGSetString(2, 6, "<S1> to start ");
	while (!(GPIOR0 & (_BV(fUPS1)))) ;				//wait for S1
	GPIOR0 &= ~(_BV(fUPS1));
#endif
#endif
	VGSetRange(0, 0);
	VGSetString(2, 6, "                ");
	setup();
	do {
		loop();
#ifndef _WIN32
		if (GPIOR0 & _BV(fSecond)) {
			GPIOR0 &= ~_BV(fSecond);
			BlinkLed0();
		}
		while (GPIOR0 & _BV(fRcvdChar)) {
			byte b = UARTReceiveByte();
			xputc(b);
		}
#endif
		if (fExit) {
			VGSetRange(0, 0);
			VGSetString(0, LASTLINEPOS, "                    ");		//TODO should be line 13
			VGSetCursorCtl(TRUE);
			VGSetClkLine(TRUE);
			VGSetCursorPos(0, 0);
			VGSetString(0, 0,  "   Thank you for    ");
			VGSetString(0, 1, "  playing Asteroids ");
			VGSetCursorPos(0, 2);
			break;
		}
	} while (TRUE);
}

