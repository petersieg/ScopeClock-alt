// Asteroids frame to be able to compile under Linux - search //PC
// (c) 2021-04-14 Peter Sieg
//
// This software is provided "AS IS" with NO WARRANTY & NO LIABILITY WHATSOEVER OF ANY KIND.

// C library headers
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

// Linux headers
#include <fcntl.h> // Contains file controls like O_RDWR
#include <errno.h> // Error integer and strerror() function
#include <termios.h> // Contains POSIX terminal control definitions
#include <unistd.h> // write(), read(), close()
#include <math.h>
#include <time.h>

int _kbhit(void) {
  struct termios oldt, newt;
  int ch;
  int oldf;

  tcgetattr(STDIN_FILENO, &oldt);
  newt = oldt;
  newt.c_lflag &= ~(ICANON | ECHO);
  tcsetattr(STDIN_FILENO, TCSANOW, &newt);
  oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
  fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

  ch = getchar();

  tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
  fcntl(STDIN_FILENO, F_SETFL, oldf);

  if(ch != EOF) {
    ungetc(ch, stdin);
    return 1;
  }
  return 0;
}


int _getch() {
    return getchar();
} 

unsigned int GetTickCount() {
    struct timespec ts;
    unsigned int theTick = 0U;
    clock_gettime( CLOCK_MONOTONIC, &ts );
    theTick  = ts.tv_nsec / 1000000;
    theTick += ts.tv_sec * 1000;
    return theTick;
}
 
#define CHAR_HEIGHT 8
#define CHAR_WIDTH 8

// ascii definitions

#define ASCII_BEL 0x07
#define ASCII_BS 0x08
#define ASCII_LF 0x0A
#define ASCII_CR 0x0D
#define ASCII_XON 0x11
#define ASCII_XOFF 0x13

typedef unsigned int uint;
typedef unsigned char byte;

int serial_port;
#define sound(x) (0)
#define kDefaultAsteroidSize 15
#define kFrameDuration  20              // The Game Frame Rate (in milliseconds)
#define kMaxBullets     25              // The maximum on-screen bullets
#define kMaxAsteroids   15              // The maximum asteroids on-screen at once xxx
#define kMinNewAsteroidInterval 600     // The minimum time interval (mS) to wait for a new asteroid to be added
#define kMaxNewAsteroidInterval 1200    // The maximum time interval (mS) to wait for a new asteroid to be added
#define kDemoWaitTime	30000			// wait time before demo mode starts
#define kFrameRedrawTime 5000			// time between frame redraws
#define BOOL bool
#define TRUE true
#define FALSE false
#define Sleep sleep

void UARTSendByte(byte x, bool y) {
  char buf[1];
  buf[0] = x;
  buf[1] = '\0';
  write(serial_port, buf, sizeof(buf) );
}

#define _WIN32 
#include "asteroids.c"

int main() {
  char c = 0;
  // for unbuffered getchar() = getch()
  static int ch = -1, fd = 0;
  struct termios neu, alt;
  fd = fileno(stdin);
  tcgetattr(fd, &alt);
  neu = alt;
  neu.c_lflag &= ~(ICANON|ECHO);
  tcsetattr(fd, TCSANOW, &neu);

  // Open the serial port. Change device path as needed (currently set to an standard FTDI USB-UART cable type device)
  serial_port = open("/dev/ttyUSB0", O_RDWR);

  // Create new termios struc, we call it 'tty' for convention
  struct termios tty;

  // Read in existing settings, and handle any error
  if(tcgetattr(serial_port, &tty) != 0) {
      printf("Error %i from tcgetattr: %s\n", errno, strerror(errno));
      return 1;
  }

  tty.c_cflag &= ~PARENB; // Clear parity bit, disabling parity (most common)
  tty.c_cflag &= ~CSTOPB; // Clear stop field, only one stop bit used in communication (most common)
  tty.c_cflag &= ~CSIZE; // Clear all bits that set the data size 
  tty.c_cflag |= CS8; // 8 bits per byte (most common)
  tty.c_cflag &= ~CRTSCTS; // Disable RTS/CTS hardware flow control (most common)
  tty.c_cflag |= CREAD | CLOCAL; // Turn on READ & ignore ctrl lines (CLOCAL = 1)

  tty.c_lflag &= ~ICANON;
  tty.c_lflag &= ~ECHO; // Disable echo
  tty.c_lflag &= ~ECHOE; // Disable erasure
  tty.c_lflag &= ~ECHONL; // Disable new-line echo
  tty.c_lflag &= ~ISIG; // Disable interpretation of INTR, QUIT and SUSP
  tty.c_iflag &= ~(IXON | IXOFF | IXANY); // Turn off s/w flow ctrl
  tty.c_iflag &= ~(IGNBRK|BRKINT|PARMRK|ISTRIP|INLCR|IGNCR|ICRNL); // Disable any special handling of received bytes

  tty.c_oflag &= ~OPOST; // Prevent special interpretation of output bytes (e.g. newline chars)
  tty.c_oflag &= ~ONLCR; // Prevent conversion of newline to carriage return/line feed
  // tty.c_oflag &= ~OXTABS; // Prevent conversion of tabs to spaces (NOT PRESENT ON LINUX)
  // tty.c_oflag &= ~ONOEOT; // Prevent removal of C-d chars (0x004) in output (NOT PRESENT ON LINUX)

  tty.c_cc[VTIME] = 10;    // Wait for up to 1s (10 deciseconds), returning as soon as any data is received.
  tty.c_cc[VMIN] = 0;

  // Set in/out baud rate to be 115200
  cfsetispeed(&tty, B115200);
  cfsetospeed(&tty, B115200);

  // Save tty settings, also checking for error
  if (tcsetattr(serial_port, TCSANOW, &tty) != 0) {
      printf("Error %i from tcsetattr: %s\n", errno, strerror(errno));
      return 1;
  }

  // Write to serial port
  
  // cls
  unsigned char cls[] = { '\xff', '\xf6', '\x0' };
  write(serial_port, cls,sizeof(cls));
  
  unsigned char msg[] = { 'H', 'e', 'l', 'l', 'o', '\r' };
  write(serial_port, msg, sizeof(msg));

  // Quadrat:
  unsigned char v1[] = { '\xff', '\xf0', '\x1', '\x40', '\x40', '\x40', '\xb0' };
  unsigned char v2[] = { '\xff', '\xf0', '\x2', '\x40', '\xb0', '\xb0', '\xb0' };
  unsigned char v3[] = { '\xff', '\xf0', '\x3', '\xb0', '\xb0', '\xb0', '\x40' };
  unsigned char v4[] = { '\xff', '\xf0', '\x4', '\xb0', '\x40', '\x40', '\x40' };
  unsigned char vd[] = { '\xff', '\xf1', '\x1', '\x4' };

  write(serial_port, v1, sizeof(v1));
  write(serial_port, v2, sizeof(v2));
  write(serial_port, v3, sizeof(v3));
  write(serial_port, v4, sizeof(v4));
  write(serial_port, vd, sizeof(vd));

  // Allocate memory for read buffer, set size according to your needs
  // char read_buf [256];

  // Normally you wouldn't do this memset() call, but since we will just receive
  // ASCII data for this example, we'll set everything to 0 so we can
  // call printf() easily.
  // memset(&read_buf, '\0', sizeof(read_buf);

  // Read bytes. The behaviour of read() (e.g. does it block?,
  // how long does it block for?) depends on the configuration
  // settings above, specifically VMIN and VTIME
  // int num_bytes = read(serial_port, &read_buf, sizeof(read_buf));

  // n is the number of bytes read. n may be 0 if no bytes were received, and can also be -1 to signal an error.
  // if (num_bytes < 0) {
  //     printf("Error reading: %s", strerror(errno));
  //     return 1;
  // }

  // Here we assume we received ASCII data, but you might be sending raw bytes (in that case, don't try and
  // print it to the screen like this!)
  // printf("Read %i bytes. Received message: %s", num_bytes, read_buf);
  
  do {
    if (_kbhit()) {
      c = _getch();
      putchar(c);
    }
  }  while (c != ' ');

  // call game loop
  Asteroid();
  
  close(serial_port);
  
  /* restore the former stdin settings */
  tcsetattr(fd, TCSANOW, &alt);
  
  return 0; // success
}

