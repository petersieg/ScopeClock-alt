//
// Vector Terminal sample application by Jan de Rie
// Based on the Arduino Slide Atari Asteroids demo program
// from Liquidware
//
// Last update: June 7, 2010
//
#include <conio.h>
#include <stdio.h>
#include <time.h>
#include <windows.h>
#include <string.h>
#include <math.h>

#define FC_DTRDSR 0x01
#define FC_RTSCTS 0x02
#define FC_XONXOFF 0x04

#define ASCII_BEL 0x07
#define ASCII_BS 0x08
#define ASCII_LF 0x0A
#define ASCII_CR 0x0D
#define ASCII_XON 0x11
#define ASCII_XOFF 0x13


HANDLE SerialInit(char*, int); 

char SerialGetc(HANDLE*);

void SerialPutc(HANDLE*, unsigned char);

// Flow control flags

#define FC_DTRDSR 0x01
#define FC_RTSCTS 0x02
#define FC_XONXOFF 0x04

#define CHAR_HEIGHT 8
#define CHAR_WIDTH 8

// ascii definitions

#define ASCII_BEL 0x07
#define ASCII_BS 0x08
#define ASCII_LF 0x0A
#define ASCII_CR 0x0D
#define ASCII_XON 0x11
#define ASCII_XOFF 0x13
//using namespace std;
// variables used with the com port
BOOL bPortReady;
DCB dcb;
COMMTIMEOUTS CommTimeouts;
BOOL bWriteRC;
BOOL bReadRC;
DWORD iBytesWritten;
DWORD dwRead;
HANDLE SerPrt = INVALID_HANDLE_VALUE;
OVERLAPPED osReader = {0};
DWORD dwEvtMask;
BOOL fWaitingOnRead = FALSE;
#define READ_BUF_SIZE 1
char InBuf[READ_BUF_SIZE];

HANDLE SerialInit(char *ComPortName, int BaudRate) 
{
	HANDLE hCom;

	hCom = CreateFileA(ComPortName, 
			GENERIC_READ | GENERIC_WRITE,
			0, // exclusive access
			NULL, // no security
			OPEN_EXISTING,
			FILE_FLAG_OVERLAPPED, // overlapped I/O
			NULL); // null template

	if (hCom == INVALID_HANDLE_VALUE) {
		DWORD err = GetLastError();
		char lpMsg[512];
		FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER |
			  FORMAT_MESSAGE_FROM_SYSTEM |
			  FORMAT_MESSAGE_IGNORE_INSERTS,
			  NULL, GetLastError(),
			  MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			  (LPTSTR)&lpMsg, 0, NULL);
		return hCom;
	}

	bPortReady = SetupComm(hCom, 2, 128); // set buffer sizes


	bPortReady = GetCommState(hCom, &dcb);
	dcb.BaudRate = BaudRate;
	dcb.ByteSize = 8;
	dcb.Parity = NOPARITY;		// EVENPARITY;
	dcb.StopBits = ONESTOPBIT;
	dcb.fAbortOnError = TRUE;

	// set XON/XOFF
	dcb.fOutX = FALSE; // XON/XOFF off for transmit
	dcb.fInX = FALSE; // XON/XOFF off for receive
	// set RTSCTS
	dcb.fOutxCtsFlow = FALSE; // turn on CTS flow control
	dcb.fRtsControl = RTS_CONTROL_DISABLE; // 
	// set DSRDTR
	dcb.fOutxDsrFlow = FALSE; // turn on DSR flow control
	dcb.fDtrControl = DTR_CONTROL_DISABLE; // DTR_CONTROL_HANDSHAKE;

	bPortReady = SetCommState(hCom, &dcb);

	// Communication timeouts are optional

	bPortReady = GetCommTimeouts (hCom, &CommTimeouts);

	CommTimeouts.ReadIntervalTimeout = 2500;
	CommTimeouts.ReadTotalTimeoutConstant = 2500;
	CommTimeouts.ReadTotalTimeoutMultiplier = 1000;
	CommTimeouts.WriteTotalTimeoutConstant = 2500;
	CommTimeouts.WriteTotalTimeoutMultiplier = 1000;

	bPortReady = SetCommTimeouts (hCom, &CommTimeouts);

	// Create Readed event

	osReader.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	if (NULL == osReader.hEvent) {
		printf("SerialInit: failure to create reader hEvent.\n");
	}

	return hCom;
}

void SerialStartRead(void)
{
	int i, err;
	if (!fWaitingOnRead) {
		// Issue Read Operation
		if (!ReadFile(SerPrt, InBuf, READ_BUF_SIZE, &dwRead, &osReader)) {
			err = GetLastError();
			if ((ERROR_IO_PENDING != err) && (ERROR_IO_INCOMPLETE != err)) {
				printf("SerialStartRead: ReadFile failed error: %d ", err);
				ClearCommError(SerPrt, &err, NULL);
				printf("detail: %x\n", err);
			} else {
				fWaitingOnRead = TRUE;
			}
		} else {
			//ReadFile finished
			for (i = 0; i < (int)dwRead; i++) {
				printf("%c", InBuf[i]);
			}
			fflush(stdout);
		}
	}
}

void SerialCheckRead(void)
{
	DWORD dwRes;
	int i, err;

	if (fWaitingOnRead) {
		dwRes = WaitForSingleObject(osReader.hEvent, 0);	// don't wait
		switch (dwRes) {
		case WAIT_OBJECT_0:	// Read Completed
			if (!GetOverlappedResult(SerPrt, &osReader, &dwRead, FALSE)) {
				err = GetLastError();
				if ((ERROR_IO_PENDING != err) && (ERROR_IO_INCOMPLETE != err)) {
					printf("SerialCheckRead: GetOverlappedResult failed error: %d ", err);
					ClearCommError(SerPrt, &err, NULL);
					printf("detail: %x\n", err);
				} else {
					// Still waiting
				}
				break;
			}
			// success
			for (i = 0; i < (int)dwRead; i++) {
				printf("%c", InBuf[i]);
			}
			fflush(stdout);
			fWaitingOnRead = FALSE;		// ready for another operation
			break;
		case WAIT_TIMEOUT:
			// still waiting
			break;
		default:
			// error
			printf("SerialCheckRead: communication error: %d\n", dwRes);
		}
	}
}

void MySleep(int mSec)
{
	while (mSec > 100) {
		SerialStartRead();
		SerialCheckRead();
		Sleep(100);
		mSec -= 100;
	}
	SerialStartRead();
	SerialCheckRead();
	Sleep(mSec);
}


void SerialPutc(HANDLE *hCom, unsigned char txchar)
{
	BOOL bWriteRC;
	static DWORD iBytesWritten;
	OVERLAPPED osWrite = {0};
	DWORD dwRes;

	// Create an event object for write operation

    osWrite.hEvent = CreateEvent(
        NULL,   // default security attributes 
        TRUE,   // manual-reset event 
        FALSE,  // not signaled 
        NULL    // no name
		);
    
	if (NULL == osWrite.hEvent) {
		printf("Error: unable to create Write Operation Event\n");
		return;
	}

	bWriteRC = WriteFile(*hCom, &txchar, 1, &iBytesWritten,&osWrite);
	if (!bWriteRC) {
		// Check if Write is pending. 
		if (ERROR_IO_PENDING != GetLastError()) {
			printf("SerialPutc: unexpected return %d from WriteFile()\n", GetLastError());
			return;
		}
		dwRes = WaitForSingleObject(osWrite.hEvent, INFINITE);
		switch (dwRes) {
		case WAIT_OBJECT_0:
			if (0 == GetOverlappedResult(*hCom, &osWrite, &iBytesWritten, TRUE)) {
				printf("GetOverlappedResult failed with error %d.\n", GetLastError());
			} else {
				// success
			}
			break;
		default:
			printf("WaitForSingleObject failed with error %d.\n", dwRes);
			break;
		}
	} else {
		// WriteFile() returned TRUE
		DWORD err = GetLastError();	//returns 995, Operation Aborted
	}
	CloseHandle(osWrite.hEvent);

	SerialStartRead();
	SerialCheckRead();
}

typedef unsigned int uint;

#define UARTSendByte(x,y) SerialPutc(&SerPrt, x)
#define sound(x) (0)
#define kDefaultAsteroidSize 15
#define kFrameDuration  20              // The Game Frame Rate (in milliseconds)
#define kMaxBullets     25              // The maximum on-screen bullets
#define kMaxAsteroids   15              // The maximum asteroids on-screen at once xxx
#define kMinNewAsteroidInterval 600     // The minimum time interval (mS) to wait for a new asteroid to be added
#define kMaxNewAsteroidInterval 1200    // The maximum time interval (mS) to wait for a new asteroid to be added
#define kDemoWaitTime	30000			// wait time before demo mode starts
#define kFrameRedrawTime 5000			// time between frame redraws

#include "Asteroids.c"

//
// accept ONE argument digit 0..9 to indicate the serial port to use.
int main(int argc, char *argv[])
{
	int i, Xpos = 1;
	int	tmp, cnt = 0;
	int port = 1;
	unsigned int n = 0;
	unsigned int timeCnt = 0;
	unsigned int x;
	char SerialPortStr[] = "\\\\.\\COMX";
	int baudrate = 115200;
	BOOL foundBaud = FALSE;

	i = 1;
	while (argc-- > 1) {
		tmp = atoi(argv[i++]);
		if (tmp > 9)  {
			// assume this is the baudrate if not specified yet
			if (!foundBaud) {
				baudrate = tmp;
				foundBaud = TRUE;
			} else {
				printf("Invalid COM port number detected. Using COM0:\n");
				port = 0;
			}
		} else {
			port = tmp;
		}
	}
	SerialPortStr[7] = port + '0';
	printf("Using COM%c: at %d baud\n", port + '0', baudrate);
	SerPrt = SerialInit(SerialPortStr, baudrate);
	if (SerPrt == INVALID_HANDLE_VALUE) {
		printf("Unable to Open COM%c:\n", port + '0');
		return FALSE;
	}
	srand((unsigned int)GetTickCount());
#if 0
	// test terminal by sending random chars, spiked with the Graphics ESC char 0xff
	timeCnt = GetTickCount();
	do {
		SerialPutc(&SerPrt, rand());
		MySleep(0);
		if ((++n & 0x000000ff) == 0) {
			SerialPutc(&SerPrt, 0xff);
		}
		if (((x = GetTickCount()) - timeCnt) >= 10000) {
			printf("char cnt: %ul, TickCnt: %ul, TimeCnt: %ul\n", n, x, timeCnt);
			timeCnt = x;
		}
	} while (1);
#endif
	Asteroid();
	return 0;

}

