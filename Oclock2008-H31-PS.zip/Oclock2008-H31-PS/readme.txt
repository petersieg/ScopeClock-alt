Modifications to Hardware 3.1 schematics:

Use 1K values for R7 & R8. Silkscreen wrong.

Stud mounting holes for BNC connectors need to be plated through. They are not by default, making it difficult to secure the BNC connectors to the PCB. This can be accomplished by adding a small copper ring around the stud mounting holes. The electrical connections are just fine.


